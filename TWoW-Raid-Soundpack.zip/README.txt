TURTLE WOW BOSS SOUND PACK
==========================

Custom voice lines for AQ40 and Naxxramas bosses.

INSTALLATION
------------
1. Double-click INSTALL.bat
2. The installer will auto-detect your Turtle WoW folder
3. Done! Start the game and raid.

UNINSTALLATION
--------------
1. Double-click UNINSTALL.bat
2. Your original sounds will be restored

INCLUDED BOSSES
---------------
- C'Thun (6 voice lines)
- Kel'Thuzad (7 voice lines)
- Patchwerk (3 voice lines)
- Four Horsemen: Thane, Blaumeux, Zeliek, Mograine (4 voice lines)

TEST IN GAME
------------
Type this macro to test C'Thun:
/script PlaySoundFile("Sound\\Creature\\CThun\\CThunDeathIsClose.wav")

REQUIREMENTS
------------
- Windows 10/11
- Turtle WoW installed
